import { useMutation } from "@tanstack/react-query";
import { api, type InsertLead } from "@shared/routes";

// Standard API hook as per schema, though primary flow is direct-to-WhatsApp
export function useCreateLead() {
  return useMutation({
    mutationFn: async (data: InsertLead) => {
      const res = await fetch(api.leads.create.path, {
        method: api.leads.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || "Failed to create lead");
      }
      
      return res.json();
    },
  });
}
