import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface Poster {
  id: number;
  title: string;
  image: string;
}

interface PosterCarouselProps {
  title: string;
  items: Poster[];
}

export default function PosterCarousel({ title, items }: PosterCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === "left" ? scrollLeft - clientWidth + 100 : scrollLeft + clientWidth - 100;
      scrollRef.current.scrollTo({ left: scrollTo, behavior: "smooth" });
    }
  };

  return (
    <div className="mb-12 relative group">
      <h3 className="text-xl md:text-2xl font-bold mb-4 font-display flex items-center gap-3 px-4 md:px-8">
        <div className="w-1.5 h-6 bg-primary rounded-full"></div>
        {title}
      </h3>
      
      {/* Navigation Buttons (visible on hover on desktop) */}
      <button 
        onClick={() => scroll("left")}
        className="absolute left-0 top-[55%] -translate-y-1/2 z-10 bg-black/60 backdrop-blur-sm p-3 rounded-r-xl opacity-0 group-hover:opacity-100 transition-opacity hidden md:block hover:bg-primary hover:text-black"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      
      <button 
        onClick={() => scroll("right")}
        className="absolute right-0 top-[55%] -translate-y-1/2 z-10 bg-black/60 backdrop-blur-sm p-3 rounded-l-xl opacity-0 group-hover:opacity-100 transition-opacity hidden md:block hover:bg-primary hover:text-black"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Scrollable Container */}
      <div 
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto hide-scrollbar snap-x snap-mandatory px-4 md:px-8 pb-8 pt-2"
      >
        {items.map((item) => (
          <div 
            key={item.id} 
            className="relative flex-none w-[140px] md:w-[220px] aspect-[2/3] rounded-xl overflow-hidden snap-start cursor-pointer group/card transition-transform duration-300 hover:scale-105 hover:z-20 shadow-lg hover:shadow-[0_0_20px_rgba(0,255,136,0.3)] border border-transparent hover:border-primary/50"
          >
            <img 
              src={item.image} 
              alt={item.title} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover/card:scale-110"
              loading="lazy"
            />
            {/* Dark overlay that appears on hover */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/40 to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
              <span className="text-white font-bold font-display leading-tight">{item.title}</span>
              <div className="mt-2 flex items-center gap-2">
                <span className="text-xs bg-primary text-black px-2 py-0.5 rounded font-bold">4K</span>
                <span className="text-xs text-gray-300">Legendado/Dublado</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
