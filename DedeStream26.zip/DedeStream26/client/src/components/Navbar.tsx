import { useState, useEffect } from "react";
import { Menu, X, Play } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const WA_LINK = "https://wa.me/5511999999999?text=Ol%C3%A1%2C%20quero%20meu%20teste%20gr%C3%A1tis%20do%20DedeStream!";

  const navLinks = [
    { name: "Conteúdo", href: "#content" },
    { name: "Esportes", href: "#sports" },
    { name: "Vantagens", href: "#benefits" },
    { name: "Planos", href: "#pricing" },
    { name: "FAQ", href: "#faq" },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-[#050505]/80 backdrop-blur-lg border-b border-white/5 py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center box-glow transition-transform group-hover:scale-110">
            <Play className="w-4 h-4 text-black fill-black" />
          </div>
          <span className="text-xl font-bold tracking-tight font-display text-white">
            Dede<span className="text-primary text-glow">Stream</span>
          </span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-sm font-medium text-gray-300 hover:text-white transition-colors"
            >
              {link.name}
            </a>
          ))}
        </div>

        {/* Desktop CTA */}
        <div className="hidden md:block">
          <Button 
            className="bg-primary hover:bg-primary/90 text-black font-bold rounded-full px-6 btn-premium box-glow hover:box-glow-strong transition-all hover:-translate-y-0.5"
            onClick={() => window.open(WA_LINK, "_blank")}
          >
            Teste Grátis
          </Button>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-white p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-[#0d0d0d] border-b border-white/10 py-4 px-4 flex flex-col gap-4 shadow-2xl">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-base font-medium text-gray-200 hover:text-primary py-2 border-b border-white/5"
              onClick={() => setMobileMenuOpen(false)}
            >
              {link.name}
            </a>
          ))}
          <Button 
            className="w-full bg-primary hover:bg-primary/90 text-black font-bold rounded-full mt-4"
            onClick={() => {
              window.open(WA_LINK, "_blank");
              setMobileMenuOpen(false);
            }}
          >
            Liberar Teste Grátis
          </Button>
        </div>
      )}
    </nav>
  );
}
