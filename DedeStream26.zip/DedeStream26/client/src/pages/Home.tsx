import { useEffect } from "react";
import { motion, useAnimation } from "framer-motion";
import { 
  Tv, Smartphone, Monitor, ShieldCheck, Zap,
  PlayCircle, Clock, CheckCircle2, MessageCircle, Play
} from "lucide-react";
import Navbar from "@/components/Navbar";
import PosterCarousel from "@/components/PosterCarousel";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const WA_LINK = "https://wa.me/5511999999999?text=Ol%C3%A1%2C%20gostaria%20de%20assinar%20o%20DedeStream%20e%20fazer%20meu%20teste%20gr%C3%A1tis!";

// Dummy data for content
const movies = [
  { id: 1, title: "John Wick 4", image: "https://images.unsplash.com/photo-1534809044339-6898d4998408?w=500&h=750&fit=crop" }, // suit/action vibe
  { id: 2, title: "Dune: Part Two", image: "https://images.unsplash.com/photo-1547333590-bc73ca2abf5a?w=500&h=750&fit=crop" }, // desert vibe
  { id: 3, title: "Avatar: Way of Water", image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&h=750&fit=crop" }, // sci-fi
  { id: 4, title: "Oppenheimer", image: "https://images.unsplash.com/photo-1596700688320-74d3d57cc1a7?w=500&h=750&fit=crop" }, // explosion
  { id: 5, title: "Fast X", image: "https://images.unsplash.com/photo-1580273916550-e323be2ae537?w=500&h=750&fit=crop" }, // cars
  { id: 6, title: "The Matrix Resurrections", image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=500&h=750&fit=crop" }, // cyber
  { id: 7, title: "Jurassic World", image: "https://images.unsplash.com/photo-1590135310688-66258074d24f?w=500&h=750&fit=crop" }, // nature/dino
  { id: 8, title: "Titanic", image: "https://images.unsplash.com/photo-1500077423678-25eead48514a?w=500&h=750&fit=crop" }, // ocean
];

const series = [
  { id: 11, title: "Stranger Things", image: "https://images.unsplash.com/photo-1605806616949-1e87b487cb2a?w=500&h=750&fit=crop" }, // retro/dark
  { id: 12, title: "The Last of Us", image: "https://images.unsplash.com/photo-1597003462529-67d16ab08b29?w=500&h=750&fit=crop" }, // post-apoc
  { id: 13, title: "House of the Dragon", image: "https://images.unsplash.com/photo-1577493340887-b7bfff550145?w=500&h=750&fit=crop" }, // fantasy
  { id: 14, title: "Breaking Bad", image: "https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?w=500&h=750&fit=crop" }, // desert/smoke
  { id: 15, title: "The Witcher", image: "https://images.unsplash.com/photo-1601646272583-490333a436e2?w=500&h=750&fit=crop" }, // medieval
  { id: 16, title: "Peaky Blinders", image: "https://images.unsplash.com/photo-1593026362540-1b2c451528ec?w=500&h=750&fit=crop" }, // vintage suit
];

const FadeIn = ({ children, delay = 0 }: { children: React.ReactNode, delay?: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-100px" }}
    transition={{ duration: 0.6, delay, ease: "easeOut" }}
  >
    {children}
  </motion.div>
);

export default function Home() {
  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-primary selection:text-black">
      <Navbar />

      {/* HERO SECTION */}
      <section className="relative min-h-[90vh] flex items-center justify-center pt-20 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 z-0">
          {/* subtle living room/tv backdrop */}
          <div 
            className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1593784991095-a205069470b6?w=1920&q=80')] bg-cover bg-center"
          />
          {/* Dark gradients to blend background into content */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#050505]/50 via-[#050505]/80 to-[#050505]" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-transparent to-[#050505]" />
          
          {/* Neon Glow orbs - Cyan and Orange */}
          <div className="absolute top-1/4 left-1/4 w-[40vw] h-[40vw] bg-cyan-400/10 rounded-full blur-[120px] mix-blend-screen" />
          <div className="absolute bottom-0 right-1/4 w-[30vw] h-[30vw] bg-orange-500/5 rounded-full blur-[100px] mix-blend-screen" />
        </div>

        <div className="container mx-auto px-4 relative z-10 text-center max-w-4xl">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            {/* Logo */}
            <motion.img
              src="/images/dedestream-logo.jpeg"
              alt="DedeStream"
              className="h-32 md:h-40 mx-auto mb-12 drop-shadow-2xl"
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            />
            
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-md mb-8">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <span className="text-sm font-medium text-gray-300">Sinal 100% Estável • Sem Travamentos</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-black mb-6 font-display leading-[1.1] tracking-tight">
              A Revolução da Sua <br className="hidden md:block" />
              <span className="text-primary text-glow">TV Chegou.</span>
            </h1>
            
            <p className="text-lg md:text-2xl text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed">
              Mais de <strong className="text-white">100.000</strong> canais, filmes e séries em <strong className="text-white">4K</strong>. 
              Assista no celular, TV ou PC sem complicações.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button 
                className="w-full sm:w-auto text-lg h-14 px-8 rounded-full bg-primary hover:bg-primary/90 text-black font-bold btn-premium box-glow-strong hover:scale-105 transition-transform"
                onClick={() => window.open(WA_LINK, "_blank")}
              >
                <PlayCircle className="mr-2 w-5 h-5" />
                Liberar Teste Grátis
              </Button>
              <Button 
                variant="outline" 
                className="w-full sm:w-auto text-lg h-14 px-8 rounded-full border-white/20 hover:bg-white/5 text-white hover:text-primary transition-colors bg-transparent"
                onClick={() => {
                  document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Ver Planos
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CONTENT SECTION (NETFLIX STYLE) */}
      <section id="content" className="py-20 relative z-10 bg-[#050505]">
        <div className="container mx-auto px-4 mb-8 text-center md:text-left">
          <FadeIn>
            <h2 className="text-3xl md:text-4xl font-bold font-display mb-2">Catálogo Premium</h2>
            <p className="text-gray-400">Lançamentos atualizados diariamente.</p>
          </FadeIn>
        </div>

        <FadeIn delay={0.2}>
          <PosterCarousel title="Filmes Mais Assistidos" items={movies} />
        </FadeIn>
        
        <FadeIn delay={0.4}>
          <PosterCarousel title="Séries em Alta" items={series} />
        </FadeIn>
      </section>

      {/* SPORTS BANNER */}
      <section id="sports" className="py-10 relative z-10 px-4">
        <FadeIn>
          <div className="container mx-auto max-w-6xl">
            <div className="relative rounded-3xl overflow-hidden group border border-white/10 box-glow">
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-500 z-10" />
              {/* sports action stadium */}
              <img 
                src="https://images.unsplash.com/photo-1508344928928-7165b67de128?w=1200&q=80" 
                alt="Futebol e Esportes Ao Vivo" 
                className="w-full h-[400px] object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/80 to-transparent z-20 flex flex-col justify-center p-8 md:p-16">
                <h2 className="text-3xl md:text-5xl font-black font-display mb-4 max-w-xl">
                  Seu time do coração <span className="text-primary text-glow">Ao Vivo</span> e em Full HD.
                </h2>
                <p className="text-lg text-gray-300 mb-8 max-w-lg">
                  Brasileirão, Champions League, UFC, NBA, Formula 1 e muito mais. Todos os canais Premiere, Combate e ESPN liberados.
                </p>
                <Button 
                  className="w-fit bg-primary hover:bg-primary/90 text-black font-bold px-8 py-6 rounded-full text-lg box-glow hover:-translate-y-1 transition-transform"
                  onClick={() => window.open(WA_LINK, "_blank")}
                >
                  Assistir Agora
                </Button>
              </div>
            </div>
          </div>
        </FadeIn>
      </section>

      {/* BENEFITS SECTION */}
      <section id="benefits" className="py-24 bg-gradient-to-b from-[#050505] to-[#0a0a0a] relative z-10">
        <div className="container mx-auto px-4 max-w-6xl">
          <FadeIn>
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-black font-display mb-4">Por que escolher o <span className="text-primary">DedeStream?</span></h2>
              <p className="text-gray-400 max-w-2xl mx-auto text-lg">A tecnologia de streaming mais avançada do mercado, garantindo sua diversão sem dores de cabeça.</p>
            </div>
          </FadeIn>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Tv, title: "+10.000 Canais", desc: "Abertos e fechados, documentários, infantis e notícias." },
              { icon: PlayCircle, title: "+60.000 Filmes/Séries", desc: "Acervo gigante com lançamentos do cinema e streamings." },
              { icon: Zap, title: "Sem Travamentos", desc: "Servidores dedicados de alta performance P2P anti-block." },
              { icon: Monitor, title: "Qualidade 4K/FHD", desc: "Imagem cristalina com suporte a HDR em TVs compatíveis." },
              { icon: ShieldCheck, title: "Compatibilidade Total", desc: "Funciona em Smart TV, TV Box, Celular, Tablet e PC." },
              { icon: Clock, title: "Suporte 24 Horas", desc: "Atendimento humano rápido via WhatsApp para te ajudar." },
            ].map((feature, i) => (
              <FadeIn key={i} delay={i * 0.1}>
                <div className="bg-[#111] border border-white/5 rounded-2xl p-6 hover:border-primary/50 hover:bg-[#151515] transition-all duration-300 hover:-translate-y-1 group">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                    <feature.icon className="w-6 h-6 text-primary group-hover:text-black transition-colors" />
                  </div>
                  <h3 className="text-xl font-bold font-display mb-2 text-white">{feature.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{feature.desc}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* COMPATIBILITY STRIP */}
      <section className="py-12 border-y border-white/5 bg-black overflow-hidden relative">
        <div className="flex w-[200%] animate-[slide_30s_linear_infinite] opacity-50">
          {[...Array(2)].map((_, idx) => (
            <div key={idx} className="flex justify-around w-full items-center gap-12 px-6">
              <span className="text-xl font-bold font-display flex items-center gap-2"><Tv className="w-6 h-6"/> Smart TVs</span>
              <span className="text-xl font-bold font-display flex items-center gap-2"><Monitor className="w-6 h-6"/> TV Box / Firestick</span>
              <span className="text-xl font-bold font-display flex items-center gap-2"><Smartphone className="w-6 h-6"/> Android / iOS</span>
              <span className="text-xl font-bold font-display flex items-center gap-2"><Monitor className="w-6 h-6"/> Computadores</span>
            </div>
          ))}
        </div>
        <style>{`
          @keyframes slide {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
          }
        `}</style>
      </section>

      {/* PRICING SECTION */}
      <section id="pricing" className="py-24 bg-[#050505] relative z-10">
        {/* Glow effect behind pricing */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-primary/10 blur-[150px] pointer-events-none rounded-[100%]" />
        
        <div className="container mx-auto px-4 max-w-6xl relative z-20">
          <FadeIn>
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-black font-display mb-4">Escolha seu <span className="text-primary">Plano</span></h2>
              <p className="text-gray-400 max-w-2xl mx-auto text-lg">Sem fidelidade, cancele quando quiser. Pagamento seguro via PIX.</p>
            </div>
          </FadeIn>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center max-w-5xl mx-auto">
            {/* Mensal */}
            <FadeIn delay={0.1}>
              <div className="bg-[#0a0a0a] border border-white/10 rounded-3xl p-8 hover:border-white/30 transition-colors">
                <h3 className="text-2xl font-bold font-display text-white mb-2">Mensal</h3>
                <p className="text-gray-400 text-sm mb-6">Ideal para conhecer</p>
                <div className="mb-6 flex items-baseline gap-1">
                  <span className="text-4xl font-black">R$25</span>
                  <span className="text-gray-500">/mês</span>
                </div>
                <ul className="space-y-4 mb-8">
                  <li className="flex items-center gap-3 text-gray-300"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> Todos os Canais</li>
                  <li className="flex items-center gap-3 text-gray-300"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> Filmes e Séries</li>
                  <li className="flex items-center gap-3 text-gray-300"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> 1 Tela simultânea</li>
                </ul>
                <Button 
                  variant="outline"
                  className="w-full py-6 rounded-xl border-white/20 hover:bg-white/10 text-white font-bold text-lg bg-transparent"
                  onClick={() => window.open(WA_LINK, "_blank")}
                >
                  Assinar Mensal
                </Button>
              </div>
            </FadeIn>

            {/* Trimestral (Highlighted) */}
            <FadeIn delay={0.2}>
              <div className="bg-gradient-to-b from-[#111] to-[#0a0a0a] border border-primary box-glow rounded-3xl p-8 relative transform md:scale-105 z-10">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-black px-4 py-1 rounded-full text-sm font-bold shadow-lg">
                  MAIS VENDIDO
                </div>
                <h3 className="text-2xl font-bold font-display text-white mb-2">Trimestral</h3>
                <p className="text-primary text-sm mb-6 font-medium">Economize R$5,00</p>
                <div className="mb-6 flex items-baseline gap-1">
                  <span className="text-5xl font-black">R$70</span>
                  <span className="text-gray-500">/trimestre</span>
                </div>
                <ul className="space-y-4 mb-8">
                  <li className="flex items-center gap-3 text-white"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> Todos os Canais 4K/FHD</li>
                  <li className="flex items-center gap-3 text-white"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> Acervo Completo VOD</li>
                  <li className="flex items-center gap-3 text-white"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> 1 Tela simultânea</li>
                  <li className="flex items-center gap-3 text-white"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> Suporte VIP</li>
                </ul>
                <Button 
                  className="w-full py-6 rounded-xl bg-primary hover:bg-primary/90 text-black font-bold text-lg btn-premium shadow-[0_0_20px_rgba(0,255,136,0.3)]"
                  onClick={() => window.open(WA_LINK, "_blank")}
                >
                  Assinar Trimestral
                </Button>
              </div>
            </FadeIn>

            {/* Anual */}
            <FadeIn delay={0.3}>
              <div className="bg-[#0a0a0a] border border-white/10 rounded-3xl p-8 hover:border-white/30 transition-colors">
                <h3 className="text-2xl font-bold font-display text-white mb-2">Anual</h3>
                <p className="text-gray-400 text-sm mb-6">O melhor custo benefício</p>
                <div className="mb-6 flex items-baseline gap-1">
                  <span className="text-4xl font-black">R$240</span>
                  <span className="text-gray-500">/ano</span>
                </div>
                <ul className="space-y-4 mb-8">
                  <li className="flex items-center gap-3 text-gray-300"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> Acesso total liberado</li>
                  <li className="flex items-center gap-3 text-gray-300"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> Equivale a R$20/mês</li>
                  <li className="flex items-center gap-3 text-gray-300"><CheckCircle2 className="w-5 h-5 text-primary shrink-0"/> 1 Tela simultânea</li>
                </ul>
                <Button 
                  variant="outline"
                  className="w-full py-6 rounded-xl border-white/20 hover:bg-white/10 text-white font-bold text-lg bg-transparent"
                  onClick={() => window.open(WA_LINK, "_blank")}
                >
                  Assinar Anual
                </Button>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* REFERRAL BANNER */}
      <section className="py-12 px-4 relative z-10">
        <div className="container mx-auto max-w-4xl">
          <FadeIn>
            <div className="bg-gradient-to-r from-[#0d1f14] to-[#050505] border border-primary/30 rounded-2xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8 box-glow">
              <div className="text-center md:text-left">
                <h3 className="text-2xl md:text-3xl font-bold font-display text-white mb-2">Ganhe <span className="text-primary">1 Mês Grátis!</span></h3>
                <p className="text-gray-300">Indique um amigo. Quando ele assinar, você ganha 30 dias na sua conta por nossa conta.</p>
              </div>
              <Button 
                className="bg-white hover:bg-gray-200 text-black font-bold px-8 py-6 rounded-full whitespace-nowrap"
                onClick={() => window.open(WA_LINK, "_blank")}
              >
                Pegar meu link
              </Button>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* FAQ SECTION */}
      <section id="faq" className="py-24 bg-[#050505] relative z-10 border-t border-white/5">
        <div className="container mx-auto px-4 max-w-3xl">
          <FadeIn>
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-5xl font-black font-display mb-4">Dúvidas <span className="text-primary">Frequentes</span></h2>
            </div>
          </FadeIn>

          <FadeIn delay={0.2}>
            <Accordion type="single" collapsible className="w-full space-y-4">
              {[
                { q: "O sinal trava?", a: "Trabalhamos com servidores Premium de alta tecnologia (P2P). Isso significa que, diferente de listas antigas, nosso sistema não sofre bloqueios das operadoras e garante uma transmissão limpa e contínua, bastando apenas uma internet de 15 mega." },
                { q: "Precisa de antena?", a: "Não! O sistema é 100% via internet. Não é necessário furar paredes, passar cabos de antena ou agendar visitas de técnicos. Basta instalar o aplicativo." },
                { q: "Como recebo o acesso?", a: "Após a confirmação do pagamento, você receberá seus dados de acesso (usuário e senha) imediatamente via WhatsApp, junto com um vídeo tutorial passo a passo de como instalar no seu aparelho." },
                { q: "Funciona na minha Smart TV?", a: "Sim! Somos compatíveis com 99% das Smart TVs do mercado (Samsung, LG, Roku, Android TV, TCL), além de TV Box, celulares e computadores." }
              ].map((faq, i) => (
                <AccordionItem key={i} value={`item-${i}`} className="bg-[#111] border border-white/10 rounded-xl px-6 data-[state=open]:border-primary/50 transition-colors">
                  <AccordionTrigger className="text-lg font-medium hover:text-primary hover:no-underline text-left py-6">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-400 text-base leading-relaxed pb-6">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </FadeIn>
        </div>
      </section>

      {/* FOOTER & FINAL CTA */}
      <footer className="bg-[#020202] border-t border-white/5 pt-20 pb-10 relative overflow-hidden">
        {/* subtle glow */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full h-[1px] shadow-[0_0_50px_20px_rgba(0,255,136,0.3)]"></div>
        
        <div className="container mx-auto px-4 text-center max-w-4xl relative z-10">
          <FadeIn>
            <h2 className="text-4xl md:text-6xl font-black font-display mb-6">Pronto para dar o <span className="text-accent text-glow-orange">Play?</span></h2>
            <p className="text-xl text-gray-400 mb-10">Faça o teste gratuito e comprove a qualidade antes de assinar.</p>
            
            <Button 
              className="h-16 px-10 rounded-full bg-primary hover:bg-primary/90 text-black font-black text-xl btn-premium box-glow-strong animate-pulse mb-16"
              onClick={() => window.open(WA_LINK, "_blank")}
            >
              <MessageCircle className="mr-3 w-6 h-6" />
              Solicitar Teste Grátis no WhatsApp
            </Button>
          </FadeIn>

          <div className="border-t border-white/10 pt-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-primary flex items-center justify-center">
                <Play className="w-3 h-3 text-black fill-black" />
              </div>
              <span className="text-lg font-bold font-display text-white">Dede<span className="text-primary">Stream</span></span>
            </div>
            
            <p className="text-gray-500 text-sm">
              © {new Date().getFullYear()} DedeStream. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
