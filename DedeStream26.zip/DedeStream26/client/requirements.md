## Packages
framer-motion | Page transitions and scroll-triggered animations

## Notes
All CTAs redirect to WhatsApp as requested.
API hooks generated for completeness but primary flow is direct-to-WhatsApp.
Static images replaced with high-quality Unsplash placeholders.
